import '../styles/Home.css';

const Home = () => {
  return (
    <div className="home">
      <div className="home__card">
        <div className="home__header">
          <h1 className="home__title">Welcome </h1>
        </div>
      </div>
    </div>
  );
};

export default Home;